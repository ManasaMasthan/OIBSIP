 function convertTemperature(){
    let val=document.getElementById("input_value");
   let result=document.getElementById("result");
     let input=document.getElementById("input");
    let output=document.getElementById("output");


    val.addEventListener("keyup",convertTemperature);
    input.addEventListener("change",convertTemperature);
    output.addEventListener("change",convertTemperature);
    
     let inputvalue=input.value;
     let outputvalue=output.value;

//celsius
     if(inputvalue==="celsius" && outputvalue==="fahrenheit")
     {
         result.value=Number((val.value)*9/5 + 32);
    }
    else if(inputvalue==="celsius" && outputvalue==="kelvin")
    {
        result.value=Number(val.value)+273.15;
   }
    else if(inputvalue==="celsius" && outputvalue==="celsius")
    {
        result.value=val.value;
    }

     //fahrenheit
    if(inputvalue==="fahreinheit" && outputvalue==="celsius")
     {
             result.value=Number((val.value-32)*5)/9;
    }
    else if(inputvalue==="fahrenheit" && outputvalue==="kelvin")
    {
        result.value=Number((val.value-32)*5/9)+273.15;
   }
     else if(inputvalue==="fahrenheit" && outputvalue==="fahrenheit")
     {
         result.value=val.value;
     }
     //kelvin
     if(inputvalue==="kelvin" && outputvalue==="celsius")
     {
         result.value=Number(val.value-273.15);
     }
     else if(inputvalue==="kelvin" && outputvalue==="fahrenheit")
     {
         result.value=Number((val.value)*1.8+32);
     }
     else if(inputvalue==="kelvin" && outputvalue==="kelvin")
   {
             result.value=val.value;
     }
 }
function clearForm(){
    document.getElementById('val').value="";
    document.getElementById('result').value="";
    document.getElementById('input').value="";
    document.getElementById('output').value="";
}

