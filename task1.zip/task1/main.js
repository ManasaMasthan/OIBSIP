function moveImage(){
    var image=document.getElementById("myImage");
    image.classList.add("move");
}